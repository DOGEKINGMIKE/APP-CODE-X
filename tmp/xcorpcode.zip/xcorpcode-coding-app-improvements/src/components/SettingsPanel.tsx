import React from 'react';
import { Settings, X, Keyboard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';

interface EditorSettings {
  fontSize: number;
  tabSize: number;
  wordWrap: boolean;
  minimap: boolean;
  lineNumbers: boolean;
  autoSave: boolean;
}

interface SettingsPanelProps {
  settings: EditorSettings;
  onSettingsChange: (settings: EditorSettings) => void;
  onClose: () => void;
}

const shortcuts = [
  { keys: 'Ctrl+K', action: 'Command palette' },
  { keys: 'Ctrl+B', action: 'Toggle sidebar' },
  { keys: 'Ctrl+`', action: 'Toggle terminal' },
  { keys: 'Ctrl+F', action: 'Find' },
  { keys: 'Ctrl+H', action: 'Find & replace' },
  { keys: 'Ctrl+S', action: 'Export ZIP' },
  { keys: 'Ctrl+W', action: 'Close tab' },
  { keys: 'Ctrl+,', action: 'Settings' },
];

const SettingsPanel: React.FC<SettingsPanelProps> = ({ settings, onSettingsChange, onClose }) => {
  const update = (key: keyof EditorSettings, value: any) => {
    onSettingsChange({ ...settings, [key]: value });
  };

  return (
    <div className="h-full flex flex-col bg-[hsl(var(--explorer-background))]">
      <div className="h-9 bg-card border-b border-border flex items-center justify-between px-3 shrink-0">
        <div className="flex items-center gap-2">
          <Settings className="w-3.5 h-3.5 text-primary" />
          <span className="text-xs font-medium text-foreground">Settings</span>
        </div>
        <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-muted-foreground hover:text-foreground" onClick={onClose}>
          <X className="w-3 h-3" />
        </Button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {/* Editor section */}
        <div>
          <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground mb-3">Editor</h3>
          <div className="space-y-4">
            {/* Font Size */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-foreground">Font Size</Label>
                <span className="text-xs text-primary font-mono">{settings.fontSize}px</span>
              </div>
              <Slider
                value={[settings.fontSize]}
                onValueChange={([v]) => update('fontSize', v)}
                min={10} max={24} step={1}
                className="cursor-pointer"
              />
            </div>

            {/* Tab Size */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label className="text-xs text-foreground">Tab Size</Label>
                <span className="text-xs text-primary font-mono">{settings.tabSize}</span>
              </div>
              <Slider
                value={[settings.tabSize]}
                onValueChange={([v]) => update('tabSize', v)}
                min={2} max={8} step={2}
                className="cursor-pointer"
              />
            </div>

            {/* Toggle switches */}
            {[
              { key: 'wordWrap' as const, label: 'Word Wrap', desc: 'Wrap long lines' },
              { key: 'minimap' as const, label: 'Minimap', desc: 'Show code overview' },
              { key: 'lineNumbers' as const, label: 'Line Numbers', desc: 'Show line numbers' },
              { key: 'autoSave' as const, label: 'Auto Save', desc: 'Save on change' },
            ].map(({ key, label, desc }) => (
              <div key={key} className="flex items-center justify-between py-1">
                <div>
                  <Label className="text-xs text-foreground">{label}</Label>
                  <p className="text-[10px] text-muted-foreground">{desc}</p>
                </div>
                <Switch checked={settings[key] as boolean} onCheckedChange={v => update(key, v)} />
              </div>
            ))}
          </div>
        </div>

        {/* Keyboard shortcuts section */}
        <div>
          <div className="flex items-center gap-1.5 mb-3">
            <Keyboard className="w-3.5 h-3.5 text-muted-foreground" />
            <h3 className="text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">Keyboard Shortcuts</h3>
          </div>
          <div className="space-y-1.5">
            {shortcuts.map(s => (
              <div key={s.keys} className="flex items-center justify-between py-1">
                <span className="text-xs text-foreground">{s.action}</span>
                <kbd className="text-[10px] font-mono bg-muted text-muted-foreground px-1.5 py-0.5 rounded border border-border">
                  {s.keys}
                </kbd>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsPanel;
